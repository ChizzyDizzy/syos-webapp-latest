create
    definer = root@localhost procedure sp_expire_items()
BEGIN
    -- Mark expired items
    UPDATE items
    SET state = 'EXPIRED'
    WHERE expiry_date < CURDATE()
      AND state != 'EXPIRED';

    -- Record the expiry movements
    INSERT INTO stock_movements (item_code, movement_type, quantity, from_state, to_state, notes)
    SELECT code, 'EXPIRE', quantity, state, 'EXPIRED', 'Auto-expired'
    FROM items
    WHERE expiry_date < CURDATE()
      AND state != 'EXPIRED';
END;

