create definer = root@localhost view expiring_soon as
select `syos_db`.`items`.`code`                                        AS `code`,
       `syos_db`.`items`.`name`                                        AS `name`,
       `syos_db`.`items`.`quantity`                                    AS `quantity`,
       `syos_db`.`items`.`expiry_date`                                 AS `expiry_date`,
       `syos_db`.`items`.`state`                                       AS `state`,
       (to_days(`syos_db`.`items`.`expiry_date`) - to_days(curdate())) AS `days_until_expiry`
from `syos_db`.`items`
where ((`syos_db`.`items`.`expiry_date` is not null) and
       ((to_days(`syos_db`.`items`.`expiry_date`) - to_days(curdate())) between 0 and 7) and
       (`syos_db`.`items`.`state` not in ('EXPIRED', 'SOLD_OUT')))
order by `syos_db`.`items`.`expiry_date`;

